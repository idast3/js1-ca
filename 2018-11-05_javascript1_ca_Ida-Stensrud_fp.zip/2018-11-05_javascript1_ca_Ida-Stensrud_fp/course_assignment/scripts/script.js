var cards = document.getElementById('cards');
var myCards;

// Connect api and convert to json format
fetch('https://api.magicthegathering.io/v1/cards')
.then((response) => {
    return response.json();
})
.then((result) => {
    showData(result);
    myCards = result.cards;
})
.catch(error => console.log(error))


// Function to show cards
function showData(response) {
  var allCards = response.cards;

  for (var i = 0; i < allCards.length; i++) {

    cards.innerHTML +=
    "<div class=\"col-sm-4\">" +
         "<div class=\"card-container\">" +
            "<h4>"+ allCards[i].name + "</h4>" +
            "<img src=\"" +  allCards[i].imageUrl + "\"width=\"100%\">" +
            "<a href=\"card-specific.html?id=" + allCards[i].id + "\" class=\"btn btn-success\">View More</a>" +
        "</div>"+
    "</div>";
  }
};


// Search
var searchButton = document.getElementById('searchButton');

searchButton.addEventListener('click', function(e) {
  // delete elements
  cards.innerHTML = "";

  // get input value
  var searchInput = document.getElementById("search").value;

  // filter and look for matching results
  var names = myCards.map(function(x) {
    return x.name;
  });

  function filteredArray(search) {
   return names.filter(function(x) {
     return x.toLowerCase().indexOf(search.toLowerCase()) > -1;
   })
  };

  var searchResult = filteredArray(searchInput);

  // display result
  cards.innerHTML +=
  "<div class=\"col-sm-4\">" +
       "<div class=\"card-container\">" +
          "<h4>" + searchResult + "</h4>" +
      "</div>" +
  "</div>";


   e.preventDefault();
   e.stopPropagation();
});
