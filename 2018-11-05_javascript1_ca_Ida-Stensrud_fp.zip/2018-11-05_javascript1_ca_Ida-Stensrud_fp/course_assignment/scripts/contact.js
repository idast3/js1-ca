
var submitBtn = document.getElementById('submitContact');
var firstNameError = document.getElementById('firstNameError');
var lastNameError = document.getElementById('lastNameError');
var phoneError = document.getElementById('phoneError');
var emailError = document.getElementById('emailError');

firstNameError.style.display = "none";
lastNameError.style.display = "none";
phoneError.style.display = "none";
emailError.style.display = "none";


// Submit button validation
submitBtn.addEventListener('click', function(e){
  e.preventDefault();
  var inputName = document.getElementById("firstName").value;
  var inputLast = document.getElementById("lastName").value;
  var inputPhone = document.getElementById("phone").value;
  var inputEmail = document.getElementById("email").value;

  // Validate first name
  function checkFirstName(firstName) {
    var firstNameRequired = /[a-zA-Z.-]/g;
    if (firstName.match(firstNameRequired)) {
      firstNameError.style.display = "none";
    } else {
      firstNameError.style.display = "block";
    }
  };

  // Validate last name
  function checkLastName(lastName) {
    var lastNameRequired = /[a-zA-Z.-]/g;
    if (lastName.match(lastNameRequired)) {
      lastNameError.style.display = "none";
    } else {
      lastNameError.style.display = "block";
    }
  };

  // Validate phone number
  function checkPhone(phoneNum) {
    var phoneNumRequired = /[0-9]{3}[ .-][0-9]{3}[ .-][0-9]{4}/;
    if (phoneNum.match(phoneNumRequired)) {
      phoneError.style.display = "none";
    } else {
      phoneError.style.display = "block";
    }
  };

  // Validate email address
  function checkEmail(emailAdr) {
    var emailRequired = /^[a-zA-Z0-9.-_]+@[a-zA-Z0-9.-_]+\.[a-zA-Z]{2,4}$/;
    if (emailAdr.match(emailRequired)) {
      emailError.style.display = "none";
    } else {
      emailError.style.display = "block";
    }
  };

  // Call functions
  checkFirstName(inputName);
  checkLastName(inputLast);
  checkPhone(inputPhone);
  checkEmail(inputEmail);
});
