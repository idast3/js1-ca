// Replace words
var aboutText = document.getElementById('aboutText');
var firstText = aboutText.textContent;
var replaced = firstText.replace(/Magic/gi, "Something");

aboutText.innerHTML = "<p>" + replaced + "</p>";

var moreInfoTrigger = document.getElementById('moreInfoTrigger');
var moreInfoContent = document.getElementById('moreInfoContent');


// Toggle info display
moreInfoTrigger.addEventListener('click', function (e) {
  if (moreInfoContent.style.display === "none") {
    moreInfoContent.style.display = "block";
  } else {
    moreInfoContent.style.display = "none";
  }
});
